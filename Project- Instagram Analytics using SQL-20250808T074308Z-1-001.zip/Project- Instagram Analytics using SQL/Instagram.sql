use ig_clone;
show tables;
-- Check for duplicates in all tables
SELECT 'users' AS table_name, COUNT(*) - COUNT(DISTINCT id) AS duplicates FROM users
UNION ALL
SELECT 'likes', COUNT(*) - COUNT(DISTINCT CONCAT(user_id, photo_id)) FROM likes
UNION ALL
SELECT 'follows', COUNT(*) - COUNT(DISTINCT CONCAT(follower_id, followee_id)) FROM follows
UNION ALL
SELECT 'comments', COUNT(*) - COUNT(DISTINCT id) FROM comments
UNION ALL
SELECT 'photos', COUNT(*) - COUNT(DISTINCT id) FROM photos
UNION ALL
SELECT 'photo_tags', COUNT(*) - COUNT(DISTINCT CONCAT(photo_id, tag_id)) FROM photo_tags;

-- Check for NULL values in all tables
SELECT 'users' AS table_name, COUNT(*) - COUNT(username) AS null_values FROM users
UNION ALL
SELECT 'likes', COUNT(*) - COUNT(photo_id) FROM likes
UNION ALL
SELECT 'follows', COUNT(*) - COUNT(followee_id) FROM follows
UNION ALL
SELECT 'comments', COUNT(*) - COUNT(comment_text) FROM comments
UNION ALL
SELECT 'photos', COUNT(*) - COUNT(image_url) FROM photos
UNION ALL
SELECT 'photo_tags', COUNT(*) - COUNT(tag_id) FROM photo_tags;

-- obj 2
SELECT user_id, 
       COUNT(DISTINCT photo_id) AS total_likes
FROM likes GROUP BY user_id ORDER BY total_posts DESC;
select user_id,
count(id) as total_post
from photos group by user_id order by user_id;
select user_id,
count(id) as total_comments
from comments group by user_id order by user_id;

-- obj 3
SELECT AVG(tag_count) FROM (
    SELECT photo_id, COUNT(tag_id) AS tag_count FROM photo_tags GROUP BY photo_id
) AS tag_counts;

-- obj 4
SELECT user_id, 
       COUNT(*) AS total_likes, 
       (SELECT COUNT(*) FROM comments WHERE comments.user_id = likes.user_id) AS total_comments, 
       (COUNT(*) + (SELECT COUNT(*) FROM comments WHERE comments.user_id = likes.user_id)) AS total_engagement 
FROM likes 
GROUP BY user_id 
ORDER BY total_engagement DESC 
LIMIT 10;

-- obj 5
-- Most followed users
SELECT followee_id AS user_id, COUNT(follower_id) AS total_followers 
FROM follows GROUP BY followee_id ORDER BY total_followers DESC LIMIT 10;

-- Most following users
SELECT follower_id AS user_id, COUNT(followee_id) AS total_following 
FROM follows GROUP BY follower_id ORDER BY total_following DESC LIMIT 10;

-- obj 6
SELECT p.user_id, 
       COUNT(p.id) AS total_posts, 
       (SELECT COUNT(*) FROM likes WHERE likes.user_id = p.user_id) AS total_likes, 
       (SELECT COUNT(*) FROM comments WHERE comments.user_id = p.user_id) AS total_comments, 
       ((SELECT COUNT(*) FROM likes WHERE likes.user_id = p.user_id) + 
        (SELECT COUNT(*) FROM comments WHERE comments.user_id = p.user_id)) / NULLIF(COUNT(p.id), 0) 
       AS avg_engagement_per_post 
FROM photos p 
GROUP BY p.user_id 
ORDER BY user_id ;

-- obj 7
SELECT id FROM users WHERE id NOT IN (SELECT DISTINCT user_id FROM likes);

-- obj 10
SELECT users.id AS user_id, 
       COALESCE(like_count, 0) AS total_likes, 
       COALESCE(comment_count, 0) AS total_comments, 
       COALESCE(tag_count, 0) AS total_photo_tags 
FROM users
LEFT JOIN (SELECT user_id, COUNT(*) AS like_count FROM likes GROUP BY user_id) l ON users.id = l.user_id
LEFT JOIN (SELECT user_id, COUNT(*) AS comment_count FROM comments GROUP BY user_id) c ON users.id = c.user_id
LEFT JOIN (SELECT photos.user_id, COUNT(*) AS tag_count FROM photo_tags 
           JOIN photos ON photo_tags.photo_id = photos.id GROUP BY photos.user_id) t ON users.id = t.user_id
ORDER BY total_likes + total_comments DESC
LIMIT 10;

-- obj 11
SELECT users.id AS user_id, 
       COALESCE(recent_likes, 0) AS recent_likes, 
       COALESCE(recent_comments, 0) AS recent_comments, 
       (COALESCE(recent_likes, 0) + COALESCE(recent_comments, 0)) AS total_recent_engagement
FROM users
LEFT JOIN (SELECT user_id, COUNT(*) AS recent_likes FROM likes 
           WHERE created_at >= NOW() - INTERVAL 30 DAY GROUP BY user_id) l ON users.id = l.user_id
LEFT JOIN (SELECT user_id, COUNT(*) AS recent_comments FROM comments 
           WHERE created_at >= NOW() - INTERVAL 30 DAY GROUP BY user_id) c ON users.id = c.user_id
ORDER BY total_recent_engagement DESC
LIMIT 10;

-- obj 12
WITH HashtagLikes AS (
    SELECT pt.tag_id, AVG(l.user_id) AS avg_likes
    FROM photo_tags pt
    JOIN likes l ON pt.photo_id = l.photo_id
    GROUP BY pt.tag_id
)
SELECT t.id, t.tag_name, hl.avg_likes
FROM HashtagLikes hl
JOIN tags t ON hl.tag_id = t.id
ORDER BY hl.avg_likes DESC
LIMIT 10;

-- obj 13
SELECT DISTINCT f1.follower_id 
FROM follows f1 
WHERE f1.followee_id IN (SELECT f2.follower_id FROM follows f2 WHERE f2.followee_id = f1.follower_id);














